package Controller;

import Model.enums.MainMenu;

public interface MenuController {
    public static void menuExit(MainMenu mainMenu) {}
}
