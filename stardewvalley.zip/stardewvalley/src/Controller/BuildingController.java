package Controller;
public class BuildingController implements InGameMenuController {
    // Controller for Building
}
