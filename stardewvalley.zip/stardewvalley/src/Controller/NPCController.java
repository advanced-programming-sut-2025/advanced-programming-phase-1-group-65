package Controller;
public class NPCController implements InGameMenuController {
    // Controller for NPC
}
