package Controller;

public class LoginMenuController implements MenuController {
    // contains login part and "Dont have account? Sing Up"
}
