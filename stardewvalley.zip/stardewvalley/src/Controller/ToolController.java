package Controller;
public class ToolController implements InGameMenuController {
    // Controller for Tool
}
