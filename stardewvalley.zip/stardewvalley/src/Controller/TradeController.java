package Controller;
public class TradeController implements InGameMenuController {
    // Controller for Trade
}
