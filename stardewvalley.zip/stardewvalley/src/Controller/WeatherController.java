package Controller;
public class WeatherController implements InGameMenuController {
    // Controller for Weather
}
