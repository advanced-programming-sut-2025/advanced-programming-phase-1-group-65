package Controller;
public class AnimalController implements InGameMenuController {
    // Controller for Animal
}
