package Controller;
public class MapController implements InGameMenuController {
    // Controller for Map
}
