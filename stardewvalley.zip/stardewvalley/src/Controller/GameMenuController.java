package Controller;

public class GameMenuController implements MenuController {

}
