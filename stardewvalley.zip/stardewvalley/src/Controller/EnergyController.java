package Controller;
public class EnergyController implements InGameMenuController {
    // Controller for Energy

}
