package Controller;

import Model.enums.MainMenu;

public interface InGameMenuController {
    public static void menuExit(MainMenu mainMenu) {}
}
