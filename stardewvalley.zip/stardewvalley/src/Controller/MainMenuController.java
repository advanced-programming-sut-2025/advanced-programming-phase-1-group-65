package Controller;

import Model.enums.MainMenu;

public class MainMenuController implements MenuController {
    private MainMenu mainMenu;
    public MainMenuController(MainMenu mainMenu) {}
}
