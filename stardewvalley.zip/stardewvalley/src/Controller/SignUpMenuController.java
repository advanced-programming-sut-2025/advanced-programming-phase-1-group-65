package Controller;

public class SignUpMenuController implements MenuController {

}
