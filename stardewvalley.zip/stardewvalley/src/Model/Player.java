package Model;

public class Player {
    String name;
    int maxenergy = Energy.maxEnergy;
    int currentEnergy = Energy.currentEnergy;
    boolean fainted = Energy.fainted;




}
