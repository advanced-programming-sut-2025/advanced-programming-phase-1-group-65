package Model;

public class Quests {
    private String NPCquest;

}
