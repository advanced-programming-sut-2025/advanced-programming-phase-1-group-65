package Model;
public class Weather {
    private String condition;
    private boolean lightning;
    private boolean GreenHouse;
    private boolean CrowAttack;
}
