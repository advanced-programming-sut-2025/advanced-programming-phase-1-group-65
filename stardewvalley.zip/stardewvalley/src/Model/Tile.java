package Model;

public class Tile {
    private int x;
    private int y;
    public boolean isWalkable;

}
