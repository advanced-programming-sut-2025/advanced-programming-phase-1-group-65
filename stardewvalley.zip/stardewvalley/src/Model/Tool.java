package Model;
public abstract class Tool extends Item {
    private String name;
    private int level;
    private int energyCost;
    private String usage;
    public String CurrentTool;
    private int Price;

    public Tool(String name, int level, int energyCost, String usage) {
        this.name = name;
        this.level = level;
        this.energyCost = energyCost;
        this.usage = usage;
    }
    public String getName() {
        return name;
    }
}
