package Model;

public class Item {
    String name;
    int number;
    String type;

    int energy;
}
