package Model;
public class Building {
    private String name;
    private String type;
    private int x;
    private int y;


    public Building(String name, String type) {
        this.name = name;
        this.type = type;

    }
}
