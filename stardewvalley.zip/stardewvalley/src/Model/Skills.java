package Model;

public class Skills {
    public int FarmingSkill;
    public int MiningSkill;
    public int HarvestSkill;
    public int FishingSkill;


}
