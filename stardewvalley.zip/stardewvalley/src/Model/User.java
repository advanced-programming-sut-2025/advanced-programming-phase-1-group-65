package Model;

public class User {

    private String username;
    private String password;
    private String email;



}
