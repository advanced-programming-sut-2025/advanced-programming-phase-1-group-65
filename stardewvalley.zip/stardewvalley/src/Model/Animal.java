package Model;

import Model.enums.AnimalType;

public class Animal {
    private String name;
    private AnimalType type;
    private boolean produces;
    private int FriendSheepPoint;

    public Animal(String name, AnimalType type, boolean produces) {
        this.name = name;
        this.type = type;
        this.produces = produces;
    }
}
