package Model;

public class Inventory {

    private int InventoryCapacity;
    Food[] foods;
    Tool[] tools;
    public Inventory() {

    }
}
