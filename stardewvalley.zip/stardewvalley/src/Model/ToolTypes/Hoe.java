package Model.ToolTypes;

import Model.Tool;

public class Hoe extends Tool {
    public Hoe(String name, int level, int energyCost, String usage) {
        super(name, level, energyCost, usage);
    }
}
