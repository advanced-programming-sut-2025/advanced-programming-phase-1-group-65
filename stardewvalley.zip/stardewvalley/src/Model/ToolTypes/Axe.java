package Model.ToolTypes;

import Model.Tool;

public class Axe extends Tool {
    public Axe(String name, int level, int energyCost, String usage) {
        super(name, level, energyCost, usage);
    }
}
