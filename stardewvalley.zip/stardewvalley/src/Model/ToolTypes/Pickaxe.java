package Model.ToolTypes;

import Model.Food;
import Model.Tool;

public class Pickaxe extends Tool {
    public Pickaxe(String name, int level, int energyCost, String usage) {
        super(name, level, energyCost, usage);
    }
}
