package Model.ToolTypes;

import Model.Tool;

public class MilkPail extends Tool {
    public MilkPail(String name, int level, int energyCost, String usage) {
        super(name, level, energyCost, usage);
    }
}
