package Model.ToolTypes;

import Model.Tool;

public class Backpack extends Tool {
    public Backpack(String name, int level, int energyCost, String usage) {
        super(name, level, energyCost, usage);
    }
}
