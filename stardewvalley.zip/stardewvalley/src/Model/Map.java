package Model;

public class Map {
    private String tileType;
    private  Building[] buildings;
    private Tile[] tiles;
    private PlantsAndTrees[] plants;
    private PlantsAndTrees[] trees;
    private PlantsAndTrees[] rocks;

}
