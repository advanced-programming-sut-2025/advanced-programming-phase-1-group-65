package Model.enums;

public enum FoodType {
    FRUIT;
    //ect...

}
