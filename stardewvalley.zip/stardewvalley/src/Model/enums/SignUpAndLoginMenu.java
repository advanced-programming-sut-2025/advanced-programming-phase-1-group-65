package Model.enums;

public enum SignUpAndLoginMenu {
}
