package Model.enums;

public enum MainMenu {
}
