package Model.enums;

public enum TileType {
    GRASS, CROP, LAKE, TREE, STONE, HOUSE;

}
