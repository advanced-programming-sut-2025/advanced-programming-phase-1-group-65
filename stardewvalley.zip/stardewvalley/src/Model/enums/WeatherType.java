package Model.enums;

public enum WeatherType {
    SUNNY,RAINY,STORM,SNOWY
}
