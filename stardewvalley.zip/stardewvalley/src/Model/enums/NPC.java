package Model.enums;

public enum NPC {

}
