package Model.enums;

public enum ToolMaterial {
    WOOD(40),COPPER(55),IRON(70),
    GOLD(85),IRIDIUM(100);

    private final int TilesCovered;
    ToolMaterial(int TilesCovered) {
        this.TilesCovered = TilesCovered;
    }

}
