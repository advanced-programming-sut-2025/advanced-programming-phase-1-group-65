package Model.enums;

public enum ToolType {
    HOE, PICKAXE, AXE, WATERING_CAN, FISHING_POLE, SCYTHE,SHEAR,TRASH_CAN,BACKPACK;


}
