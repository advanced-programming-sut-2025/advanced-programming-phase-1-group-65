package Model;

public class Energy {
    public static int maxEnergy;
    public static int currentEnergy;
    public static boolean fainted;

    public int getCurrentEnergy() {
        return currentEnergy;
    }

}
