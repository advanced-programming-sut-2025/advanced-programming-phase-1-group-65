package Model;

public abstract class PlantsAndTrees {
    private String name;
    public boolean isHarvestable;
    //trees, rocks....

    public void interact() {
        return;
    }
}
