package Model;
public class TimeDate {
    private int hour;
    private int day;
    private int season;


}
