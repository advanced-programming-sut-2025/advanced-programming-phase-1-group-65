package View;

public class NPCView {
    // View for NPC
}
