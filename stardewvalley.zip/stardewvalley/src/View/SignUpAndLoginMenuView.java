package View;

public class SignUpAndLoginMenuView {
}
