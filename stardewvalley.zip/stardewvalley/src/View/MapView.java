package View;

public class MapView {
    // View for Map
}
