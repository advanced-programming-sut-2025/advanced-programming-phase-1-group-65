package View;

public class ToolView {
    // View for Tool
}
