package View;

public class MainMenuView {
}
