package View;

public class BuildingView {
    // View for Building
}
