package View;

public class EnergyView {
    // View for Energy
}
