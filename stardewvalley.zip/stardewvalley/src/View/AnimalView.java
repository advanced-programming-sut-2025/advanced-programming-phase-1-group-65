package View;
public class AnimalView {
    // View for Animal
}
