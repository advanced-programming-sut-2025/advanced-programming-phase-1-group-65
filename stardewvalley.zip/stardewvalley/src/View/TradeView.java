package View;

public class TradeView {
    // View for Trade
}
