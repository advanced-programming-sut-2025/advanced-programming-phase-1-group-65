package View;

public class WeatherView {
    // View for Weather
}
