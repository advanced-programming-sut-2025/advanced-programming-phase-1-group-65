package Views;

public class ProfileMenuView {
    String input;

    public String getInput() {
        return input;
    }
    public void setInput(String input) {
        this.input = input;
    }
}
