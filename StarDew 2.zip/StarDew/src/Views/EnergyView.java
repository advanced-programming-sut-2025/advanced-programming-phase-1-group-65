package Views;

import Controllers.EnergyController;

public class EnergyView extends EnergyController {
    public int ShowCurrentEnergy(){
        return CurrentEnergy;
    }
}
