package Views;

public class SignUpMenuView {
    String input;
    public SignUpMenuView(String input) {
         this.input = input;
    }
    public String getInput() {
        return input;
    }
    public String ShowMessage() {
        return "Message";
    }
}
