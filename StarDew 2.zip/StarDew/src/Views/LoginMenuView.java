package Views;

public class LoginMenuView {
    String input;
    public String getInput() {
        return input;
    }
    public void setInput(String input) {
        this.input = input;
    }
    public String ShowMessage(String message) {
        return message;
    }
}
