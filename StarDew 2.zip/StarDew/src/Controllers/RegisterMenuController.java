package Controllers;
import Models.Enums.Menus;
public class RegisterMenuController {
    String username, password, confirmPassword;
    String email;
    String Gender;
    String NickName;
    String CurrentMenu;
    public RegisterMenuController() {
        this.CurrentMenu = String.valueOf(Menus.SIGNUP);

    }

}
