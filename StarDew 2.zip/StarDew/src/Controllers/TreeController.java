package Controllers;

public class TreeController extends FarmObjects {
    int x,y,x0,y0;
    int Size;
}
