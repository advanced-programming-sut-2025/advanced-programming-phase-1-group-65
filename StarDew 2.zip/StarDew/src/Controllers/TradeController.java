package Controllers;

import Models.Item;

public class TradeController {
    String ItemName;
    String ItemType;
    int ItemPrice;
}
