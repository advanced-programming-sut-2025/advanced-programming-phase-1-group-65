package Controllers;



public class MainMenuController {
    String username;
    String nickname;
    String password;
    String email;

}
