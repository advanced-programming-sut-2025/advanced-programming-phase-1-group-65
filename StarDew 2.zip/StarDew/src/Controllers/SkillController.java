package Controllers;

public class SkillController implements InGameController {
    public int FarmingSkill;
    public int MiningSkill;
    public int HarvestSkill;
    public int FishingSkill;
    public int ChangeSkillLevel(String skill) {
        return 0;
    }
}
