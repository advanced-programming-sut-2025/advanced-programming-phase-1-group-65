package Controllers;

public class CraftingController extends SkillController {
    String ItemName;
    boolean ISPossibleToCraft;

}
