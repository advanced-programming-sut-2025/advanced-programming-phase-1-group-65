package Controllers;

public class FarmObjects extends FarmController {               // niaaz nist
    int x0,y0, x, y;
}
