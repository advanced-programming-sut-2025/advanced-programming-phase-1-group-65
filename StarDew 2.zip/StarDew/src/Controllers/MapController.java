package Controllers;

public class MapController implements InGameController {
   public int mapNumber;
    public String mapPrinter(int x , int y, int y0 , int x0 , String Type){
        return "";
    }
}
