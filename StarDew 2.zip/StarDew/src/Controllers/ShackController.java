package Controllers;

public class ShackController extends FarmObjects {
    int x = 4;
    int y =4;
}
