package Controllers;

public class InventoryController implements InGameController {

}
