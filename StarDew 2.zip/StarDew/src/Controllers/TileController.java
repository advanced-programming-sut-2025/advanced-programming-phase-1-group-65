package Controllers;

public class TileController extends MapController {
    String Type;
    public boolean IsMovable;

}
