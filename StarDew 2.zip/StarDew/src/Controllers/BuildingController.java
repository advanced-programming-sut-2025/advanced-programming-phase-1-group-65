package Controllers;

public class BuildingController implements InGameController {
    public int x,y,x0,y0;
    String name;
    String usage;

}
