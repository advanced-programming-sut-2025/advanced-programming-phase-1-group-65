package Models;

public class Map {
    int MapNumber ;
    public Map(int MapNumber) {
        this.MapNumber = MapNumber;

    }
    public int getMapNumber() {
        return MapNumber;
    }
    public void setUpMap(){

    }
}
