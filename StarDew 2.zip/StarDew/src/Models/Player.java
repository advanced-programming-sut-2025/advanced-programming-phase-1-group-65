package Models;

public class Player extends User {
    int Energy;
    boolean Fainted;
    String name;

}
