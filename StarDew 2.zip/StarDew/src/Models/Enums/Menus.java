package Models.Enums;

public enum Menus {
    LOGIN,SIGNUP,PROFILE,GAME,AVATAR;
}
