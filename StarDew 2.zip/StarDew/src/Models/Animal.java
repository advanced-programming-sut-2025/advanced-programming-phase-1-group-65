package Models;
public class Animal {
    private String name;
    private String type;
    private boolean produces;
    private int FriendSheepPoint;

    public Animal(String name, String type, boolean produces) {
        this.name = name;
        this.type = type;
        this.produces = produces;
    }
}
