package Models.ToolTypes;

import Models.Tool;

public class Seythe extends Tool {
    public Seythe(String name, int level, int energyCost, String usage) {
        super(name, level, energyCost, usage);
    }
}
