package Models.ToolTypes;

import Models.Tool;

public class TrashCan extends Tool {
    public TrashCan(String name, int level, int energyCost, String usage) {
        super(name, level, energyCost, usage);
    }
}
