package Views;

public class GameMenuView {
    String input;
    public String getInput() {
        return input;
    }
    public void setInput(String input) {
        this.input = input;
    }
}
