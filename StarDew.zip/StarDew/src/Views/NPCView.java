package Views;

public class NPCView {
    // View for NPC
    private String name;
    public String SayDialogues(int time,String Quest){
        return Quest;
    }
}
