package Views;

public class BuildingView {
    int x,y,x0,y0;
    public String printer(int x,int x0, int y, int y0){
        return "";
    }
}
