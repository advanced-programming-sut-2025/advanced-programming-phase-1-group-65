package Views;

public class InventoryView {
    String[] Item;
    int[] Itemnumber;

}
