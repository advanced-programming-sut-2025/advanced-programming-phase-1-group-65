package Views;

import Controllers.MapController;
import java.util.Scanner;
import Models.Map;

public class InGameMapView {
    Scanner scanner = new Scanner(System.in);
    int mapNumber = scanner.nextInt();
    int width = scanner.nextInt();
    int height = scanner.nextInt();

    Map mapModel = new Map(mapNumber, width, height);
    MapController mapController = new MapController(mapModel);

    public void run() {
        mapController.receiveMap();
        mapController.displayMap(mapModel.getMap());
    }
}
