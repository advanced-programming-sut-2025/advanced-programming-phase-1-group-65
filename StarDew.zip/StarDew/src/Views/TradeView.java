package Views;

public class TradeView {
    public String ShowMessage(String Message) {
        return Message;
    }
}
