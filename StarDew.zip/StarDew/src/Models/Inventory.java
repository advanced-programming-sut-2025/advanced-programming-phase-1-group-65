package Models;

public class Inventory extends Player {

    private int InventoryCapacity;

    public Inventory() {

    }
}
