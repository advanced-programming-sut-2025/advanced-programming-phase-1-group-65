package Models.Enums;

public enum FoodType {
    FRUIT;
    //ect...

}
