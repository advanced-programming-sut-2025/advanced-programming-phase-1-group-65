package Models.ToolTypes;

import Models.Tool;

public class Hoe extends Tool {
    public Hoe(String name, int level, int energyCost, String usage) {
        super(name, level, energyCost, usage);
    }
}
