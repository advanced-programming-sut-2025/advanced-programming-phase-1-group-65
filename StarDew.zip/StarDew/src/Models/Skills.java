package Models;

public class Skills extends Player {
    public int FarmingSkill;
    public int MiningSkill;
    public int HarvestSkill;
    public int FishingSkill;


}
