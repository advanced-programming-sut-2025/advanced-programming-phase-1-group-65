package Models;
import java.util.ArrayList;
public class User {
    String username;
    String password;
    String confirmpassword;
    String email;
    String Gender;
    String Nickname;
    ArrayList<User> users;
    public boolean IsUsernameValid(String username) {
        return true;
    }
    public boolean IsPasswordValid(String password) {
        return true;
    }
    public boolean IsEmailValid(String email) {
        return true;
    }
    public boolean IsGenderValid(String gender) {
        return true;
    }
    public boolean IsUsernameTaken(String username) {
        return true;
    }
    public boolean IsconfirmpasswordValid(String confirmpassword) {
        return true;
    }
    public static String forgetPassword(String username) {
        return "";
    }

}
