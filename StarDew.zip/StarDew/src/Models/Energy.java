package Models;

public class Energy extends Player{
    public int EnergyCost;


}
