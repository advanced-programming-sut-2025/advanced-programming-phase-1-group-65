package Models;

import java.util.Random;

public class Map {
    int mapNumber;
    private int height;
    private int width;
    private char[][] map;
    private Random random;

    public Map(int mapNumber, int height, int width) {
        this.mapNumber = mapNumber;
        this.height = height;
        this.width = width;
        this.map = new char[height][width];
        this.random = new Random();
        generateMap(mapNumber);
    }

    public int getMapNumber() {
        return mapNumber;
    }
    public void setUpMap(){}

    private void generateMap(int mapNumber) {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                map[i][j] = '.';
            }
        }

        switch (mapNumber) {
            case 1:
                generateFixedObjects(1);
                generateRandomObjects();
                break;
            case 2:
                generateFixedObjects(2);
                generateRandomObjects();
                break;
            case 3:
                generateFixedObjects(3);
                generateRandomObjects();
                break;
            default:
                generateFixedObjects(4);
                generateRandomObjects();
                break;
        }
    }

    private void generateFixedObjects(int mapNumber) {
        switch (mapNumber) {
            case 1:
                for (int i = width - 1; width - 5 < i; i--) {
                    for (int j = 0; j < 4; j++) {
                        map[i][j] = 'H';                                // H as Home
                    }
                }
                for (int i = 0; i < 6; i++) {
                    for (int j = 0; j < 5; j++) {
                        map[i][j] = 'G';                                // G as Greenhouse
                    }
                }
                for (int i = 0; i < 6; i++) {
                    for (int j = height - 1; height - 6 < j; j--) {
                        map[i][j] = 'M';                                // M as Mine  6 * 5
                    }
                }
                for (int i = width - 1; width - 9 < i; i--) {
                    for (int j = height - 1; height - 7 < j; j--) {
                        map[i][j] = 'L';                                // L as Lake  8 * 6
                    }
                }
                break;
            case 2:
                for (int i = 0; i < 4; i++) {
                    for (int j = 0; j < 4; j++) {
                        map[i][j] = 'H';                                // H as Home
                    }
                }
                for (int i = 0; i < 6; i++) {
                    for (int j = height - 1; height - 6 < j; j--) {
                        map[i][j] = 'G';                                // G as Greenhouse
                    }
                }
                for (int i = height - 1; height - 7 < i; i--) {
                    for (int j = height - 1; height - 6 < j; j--) {
                        map[i][j] = 'M';                                // M as Mine
                    }
                }
                for (int i = width - 1; width - 9 < i; i--) {
                    for (int j = 0; j < 6; j++) {
                        map[i][j] = 'L';                                // L as Lake
                    }
                }
                break;
            case 3:
                for (int i = ((int) width/2)-2; i < ((int) width/2) + 2; i++) {
                    for (int j = height - 1; height - 5 < j; j--) {
                        map[i][j] = 'H';                                // H as Home
                    }
                }
                for (int i = 0; i < 6; i++) {
                    for (int j = ((int) height/2)+2; ((int) height/2)-3 < j; j--) {
                        map[i][j] = 'G';                                // G as Greenhouse
                    }
                }
                for (int i = ((int) width/2)-2; i < ((int) width/2) + 2; i++) {
                    for (int j = 0; j < 5; j++) {
                        map[i][j] = 'M';                                // M as Mine
                    }
                }
                for (int i = width - 1; width - 9 < i; i--) {
                    for (int j = ((int) height/2)+3; ((int) height/2)-3 < j; j--) {
                        map[i][j] = 'L';                                // L as Lake
                    }
                }
                break;
            default:
                for (int i = ((int) width/2)-2; i < ((int) width/2) + 2; i++) {
                    for (int j = height - 1; height - 5 < j; j--) {
                        map[i][j] = 'H';                                // H as Home
                    }
                }
                for (int i = width - 1; width - 7 < i; i--) {
                    for (int j = 0; j < 5; j++) {
                        map[i][j] = 'G';                                // G as Greenhouse
                    }
                }
                for (int i = 0; i < 6; i++) {
                    for (int j = 0; j < 5; j++) {
                        map[i][j] = 'M';                                // M as Mine
                    }
                }
                for (int i = ((int) width/2)-4; i < ((int) width/2)+4; i++) {
                    for (int j = ((int) height/2)+3; ((int) height/2)-3 < j; j--) {
                        map[i][j] = 'L';                                // L as Lake
                    }
                }
                break;
        }
    }

    private void generateRandomObjects() {
        int numOfTrees = random.nextInt(3) + 2;
        int numOfForagings = random.nextInt(3) + 2;
        int numOfRocks = random.nextInt(1) + 2;

        generateRandomTrees(numOfTrees);
        generateRandomForagings(numOfForagings);
        generateRandomRocks(numOfRocks);
    }

    private void generateRandomTrees(int numOfTrees) {
        // Different type of trees should be added.

        for (int i = 0; i < numOfTrees; i++) {
            int x = random.nextInt(width);
            int y = random.nextInt(height);
            while (map[x][y] != '.') {
                x = random.nextInt(width);
                y = random.nextInt(height);
            }
            map[x][y] = 'T';
        }
    }
    private void generateRandomForagings(int numOfForagings) {
        for (int i = 0; i < numOfForagings; i++) {
            int x = random.nextInt(width);
            int y = random.nextInt(height);
            while (map[x][y] != '.') {
                x = random.nextInt(width);
                y = random.nextInt(height);
            }
            map[x][y] = '@';                        // @ as Foraging
        }
    }
    private void generateRandomRocks(int numOfRocks) {
        for (int i = 0; i < numOfRocks; i++) {
            int x = random.nextInt(width);
            int y = random.nextInt(height);
            while (map[x][y] != '.') {
                x = random.nextInt(width);
                y = random.nextInt(height);
            }
            map[x][y] = 'R';                        // R as rock
        }
    }

    public char[][] getMap() {
        return map;
    }
}
