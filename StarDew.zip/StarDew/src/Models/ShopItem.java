package Models;

public class ShopItem extends Item {
    int price;
    String Name;
    String Type;
    String Shop;
    String Description;
}
