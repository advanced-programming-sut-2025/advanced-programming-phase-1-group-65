package Models;

public class Item {
    String Usage;
    String Type;
}
