package Models;

public class Tool extends Item {
   public int level;
    public int priceToUse;
    public String Usage;

    public Tool(String name, int level, int energyCost, String usage) {
        super();
    }
}
