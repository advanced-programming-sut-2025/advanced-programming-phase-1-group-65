package Controllers;
import Models.Enums.Menus;
public class LoginMenuController extends RegisterMenuController {
    String username;
    String password;
    LoginMenuController(String username, String password) {
        super(String.valueOf(Menus.LOGIN));
        this.username = username;
        this.password = password;
    }
}
