package Controllers;

public class WeatherController extends SeasonController {
    String Weather;
    private int ChangeWeather(String Weather) {
        return 0;

    }
    public boolean Thunder;
    public boolean GreenHouse;
}
