package Controllers;

public class ShopController extends BuildingController {
    String ShopName;
    String NPCName;


}
