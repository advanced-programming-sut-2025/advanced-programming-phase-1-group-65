package Controllers;

public class SignUpMenuController extends RegisterMenuController {
    String username, password, confirmPassword;
    String email;
    String Gender;
    String NickName;
    SignUpMenuController(String username, String password, String confirmPassword, String email, String Gender, String NickName) {
        this.username = username;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.email = email;
        this.Gender = Gender;
        this.NickName = NickName;
    }
}
