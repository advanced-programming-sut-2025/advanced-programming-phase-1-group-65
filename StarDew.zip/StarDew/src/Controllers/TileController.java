package Controllers;

import Models.Map;

public class TileController extends MapController {
    String Type;
    public boolean IsMovable;

    public TileController(Map map) {
        super(map);
    }
}
