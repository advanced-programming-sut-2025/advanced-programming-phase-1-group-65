package Controllers;

public class LakeController extends FarmObjects {

}
