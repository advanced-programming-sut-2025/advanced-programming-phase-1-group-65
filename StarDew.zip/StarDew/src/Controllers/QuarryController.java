package Controllers;

public class QuarryController extends FarmObjects {
    int x,y,x0,y0;
}
