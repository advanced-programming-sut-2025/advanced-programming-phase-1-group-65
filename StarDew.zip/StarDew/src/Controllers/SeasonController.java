package Controllers;

public class SeasonController extends TimeController {
    private String Season;

   public int ChangeSeason(int time) {
       return 0;
   }
}
