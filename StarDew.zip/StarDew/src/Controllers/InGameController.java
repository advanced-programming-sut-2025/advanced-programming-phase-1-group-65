package Controllers;

import Models.Enums.Menus;

public interface InGameController {
    public static void menuExit(Menus mainMenu) {}
}
