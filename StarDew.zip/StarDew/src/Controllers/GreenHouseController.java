package Controllers;

public class GreenHouseController extends FarmObjects {
    int x=5;
    int y =6;

}
