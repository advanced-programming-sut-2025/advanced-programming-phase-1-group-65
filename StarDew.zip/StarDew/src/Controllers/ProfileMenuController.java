package Controllers;

public class ProfileMenuController extends MainMenuController{
    int MostGoldInOneGame;
    int GamesPlayed;
    public void ChangeUsername(String username) {
        return;
    }
    public void ChangePassword(String newPassword, String oldPassword) {
        return;
    }
    public void ChangeEmail(String email) {
        return;
    }
    public void ChangeNickname(String nickname) {
        return;
    }
}
