package Controllers;

import Models.Player;

public class EnergyController implements InGameController {
    public int CurrentEnergy;
    public boolean Fainted;
    public int EnergyGiven(int energyGiven){
        CurrentEnergy += energyGiven;
        return CurrentEnergy;
    }
    public int EnergyTaken(int energyTaken){
        CurrentEnergy -= energyTaken;
        return CurrentEnergy;
    }


}
