package Controllers;

public class TimeController implements InGameController {

    private int time;
    private int date;
    private String DaysOfWeek;
    public int ChangeTime(int time) {
        return 0;
    }


}
