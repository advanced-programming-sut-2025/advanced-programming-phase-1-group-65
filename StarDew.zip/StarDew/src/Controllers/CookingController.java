package Controllers;

public class CookingController implements InGameController{
    public String name;
    public boolean Refrigerator;
}
