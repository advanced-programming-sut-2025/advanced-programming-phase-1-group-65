package Controllers;

import Models.Map;

public class MapController implements InGameController {
    private Map mapModel;
    private char[][] map;

    public MapController(Map mapModel) {
        this.mapModel = mapModel;
    }

    public void receiveMap(){
        char[][] map = mapModel.getMap();
    }

    public static void coloredPrint(char character){
        switch (character){
            case 'H':
                System.out.print("\u001B[38;5;94m" + 'H' + ' ' + "\u001B[0m");                      // Brown for home
                break;
            case 'M':
                System.out.print("\u001B[38;5;250m" + 'M' + ' ' + "\u001B[0m");                     // Light grey for mine
                break;
            case 'G':
                System.out.print("\u001B[38;5;240m" + 'G' + ' ' + "\u001B[0m");                     // Dark grey for greenhouse
                break;
            case 'L':
                System.out.print("\u001B[34m" + 'L' + ' ' + "\u001B[0m");                           // Blue for lake
                break;
            case 'T':
                System.out.print("\u001B[32m" + 'T' + ' ' + "\u001B[0m");                           // Green for tree
                break;
            case '@':
                System.out.print("\u001B[32m" + '@' + ' ' + "\u001B[0m");                           // Green also for foragings
                break;
            case 'R':
                System.out.print("\u001B[38;5;254m" + 'R' + ' ' + "\u001B[0m");                           // Soft grey for rock
                break;
            default:
                System.out.print(character + ' ');
                break;
        }
    }

    public void displayMap(char[][] map) {
        for(int i = 0; i < map.length; i++) {
            for(int j = 0; j < map[0].length; j++) {
                coloredPrint(map[i][j]);
            }
            System.out.println();
        }
    }


}
