package Controllers;

public class RockController extends FarmObjects {
    int x,y,x0,y0;
    int Size;
}
