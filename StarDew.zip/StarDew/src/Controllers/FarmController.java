package Controllers;

public class FarmController implements InGameController {
    int x0,y0, x, y;

}
